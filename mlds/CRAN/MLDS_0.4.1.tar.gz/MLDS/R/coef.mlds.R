`coef.mlds` <- function(object, ...){
	cc <- object$pscale[-1]
	names(cc) <- object$stimulus[-1]
	cc	
}	

`coef.mlbs` <- function(object, ...){
	cc <- object$pscale[-1]
	names(cc) <- object$stimulus[-1]
	cc	
}	