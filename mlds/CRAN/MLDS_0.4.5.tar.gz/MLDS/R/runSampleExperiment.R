runSampleExperiment <- function(DisplayTrial, DefineStimuli) .Defunct("runQuadExperiment", "MLDS",
	"Defunct! \n \n Replaced by runQuadExperiment or runTriadExperiment")